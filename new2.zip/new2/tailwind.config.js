module.exports = {
  content: [

  "./src/**/*.{js,jsx,ts,tsx}",

  ],

  theme: {

  extend: {

    backgroundImage:{

      'logo2': "url('/img/logo2.png')",

    },

  },

  },

  plugins: [],

  }