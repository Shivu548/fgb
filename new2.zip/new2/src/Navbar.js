import React from 'react';
import './Style.css';
import { ChatSharp, MenuOutlined, NotificationImportantOutlined, SearchOutlined, ShoppingCart } from '@material-ui/icons';


const Navbar = () => {
  return (
    <div>
      <nav class="bg-white">
          <div class="flex">
              <div class=" mr-auto mt-6 px-10">
                <MenuOutlined/>
              </div>
              <div class="flex justify-self-end pb-2">
                  <div class="mr-8 mt-6"><SearchOutlined/></div>
                  <div class="mr-8 mt-6"><NotificationImportantOutlined/></div>
                  <div class="mr-8 mt-6"><ChatSharp/></div>
                  <div class="mr-8 mt-6"><ShoppingCart/></div>
                  <div class="h-10 w-10 mr-6 mt-3"><img src="/img/ab.png" class= " rounded-full "/></div>
              </div>
          </div>
      </nav>
    </div>
  )
}
export default Navbar