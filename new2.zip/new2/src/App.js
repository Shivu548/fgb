import React from 'react'
import './Style.css'
import Navbar from './Navbar'
import Part1 from './Part1'
import Part2 from './Part2'
import Project from './Project'

const App = () => {
  return (
    <div>
      {/* <Navbar/>
      <Part1/>
      <Part2 /> */}
      <Project/>

    </div>
  )
}

export default App