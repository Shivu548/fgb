import { Message } from '@material-ui/icons';
import React from 'react';
import './Style.css';

const Part2 = () => {
  return (
    <div>
      <nav>
          <div class="grid grid-cols-5 text-white rounded mt-6 bg-slate-300">
            <div></div>
            <div class="flex bg-purple-500 w-60 rounded ">
             <img src="/img/msg.png" class="h-20 w-20 p-5 bg-purple-600 rounded-l-lg"/>
             <div class="pt-3 px-3">
                <h4 class="font-bold text-xl">210</h4>
                <h4 class=" text-lg">Unread Email</h4>
             </div>
             </div>

             <div class="flex bg-sky-400 w-60 rounded">
             <img src="/img/cam.png" class="h-20 w-20 p-5 bg-sky-500 rounded-l-lg"/>
             <div class="pt-3 px-3">
                <h4 class="font-bold text-xl">210</h4>
                <h4 class="text-lg">Image Upload</h4>
             </div>
             </div>

             <div class="flex bg-lime-400 w-60 rounded">
             <img src="/img/chat.png" class="h-20 w-20 p-5 bg-lime-500 rounded-l-lg"/>
             <div class="pt-3 px-3">
                <h4 class="font-bold text-xl">210</h4>
                <h4 class=" text-lg">Total Message</h4>
             </div>
             </div>

             <div class="flex bg-pink-400 w-60 rounded">
             <img src="/img/cart.png" class="h-20 w-20 p-5 bg-pink-500 rounded-l-lg"/>
             <div class="pt-3 px-3">
                <h4 class="font-bold text-xl">210</h4>
                <h4 class=" text-lg">Orders Post</h4>
             </div>
             </div>
          </div>
      </nav>
      
      <div class="grid grid-cols-5 bg-slate-300 pb-6">
        <div></div>
        <div class="p-4 bg-white mr-3 mt-4 w-60">
          <h4 class="font-bold text-sm pb-4">INCOME</h4>
          <h4 class="text-3xl text-pink-500 pb-5">$15000</h4>
          <h4 class=" w-52 pb-4">Lorem ipsum dolor sit amet consectetur adipisicing elit sed do eiusmod tempor</h4>
        </div>

        <div class="p-4 bg-white mr-3 mt-4 w-60">
          <h4 class="font-bold text-sm pb-4">INCOME</h4>
          <h4 class="text-3xl text-pink-500 pb-5">$15000</h4>
          <h4 class=" w-52 pb-4">Lorem ipsum dolor sit amet consectetur adipisicing elit sed do eiusmod tempor</h4>
        </div>
        
        <div class="p-4 bg-white mr-3 mt-4 w-60">
          <h4 class="font-bold text-sm pb-4">INCOME</h4>
          <h4 class="text-3xl text-pink-500 pb-5">$15000</h4>
          <h4 class=" w-52 pb-4">Lorem ipsum dolor sit amet consectetur adipisicing elit sed do eiusmod tempor</h4>
        </div>

        <div class="p-4 bg-white mr-3 mt-4 w-60">
          <h4 class="font-bold text-sm pb-4">INCOME</h4>
          <h4 class="text-3xl text-pink-500 pb-5">$15000</h4>
          <h4 class=" w-52 pb-4">Lorem ipsum dolor sit amet consectetur adipisicing elit sed do eiusmod tempor</h4>
        </div>
      </div>

    </div>
  )
}

export default Part2





