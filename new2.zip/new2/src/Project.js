import React from 'react';
import './Style.css';
import logo from './logo1.png';
// import logo15 from './sr'
import {AiOutlineHome} from 'react-icons/ai';

import {FiSettings} from 'react-icons/fi';

import {AiOutlineAppstore} from 'react-icons/ai';
import {GoThreeBars} from 'react-icons/go';
import {BiNotepad} from 'react-icons/bi';
import {AiFillEdit} from 'react-icons/ai';
import {BsBarChart} from 'react-icons/bs';
import {RiTable2} from 'react-icons/ri';
import {MdOutlineNotifications} from 'react-icons/md';
import {BsEmojiSmile} from 'react-icons/bs';
import {SiGooglemaps} from 'react-icons/si';
import {GiPapers} from 'react-icons/gi';
import {BiMessageAltError} from 'react-icons/bi';
import {RiFilePaper2Line} from 'react-icons/ri';
import {AiOutlineShoppingCart} from 'react-icons/ai';
import {GrDocumentStore} from 'react-icons/gr';
import {MdOutlineColorLens} from 'react-icons/md';
import AppsIcon from '@mui/icons-material/Apps';


import { ChatSharp, MenuOutlined, NotificationImportantOutlined, SearchOutlined, ShoppingCart } from '@material-ui/icons';
import MailOutlineIcon from '@mui/icons-material/MailOutline';
const Project = () => {
  return (
    <div class="grid grid-cols-5 " style={{color:'#e5e6eb'}}>
        <div class="col-span-1">

<table style={{color:'#e5e6eb'}}>
  <div class="logo"> <img src={logo} alt="logo"/> <h4  style={{color:'	#686868'}}>JustDo </h4> </div>
{/* 
  <div style={{color:'	#686868'}}>  &nbsp; &nbsp; &nbsp; JustDo </div> */}

  <div class="flex px-3 pt-2 pb-2" style={{color:'	#686868'}}> <AiOutlineHome/> &nbsp; &nbsp;Dashboard</div>
  <div class="flex px-3 pt-2 pb-2" style={{color:'	#686868'}}> <FiSettings/>&nbsp; &nbsp;Widgets</div>
  <div class="flex px-3 pt-2 pb-2" style={{color:'	#686868'}}> <AiOutlineAppstore/>&nbsp; &nbsp;Apps</div>
  <div class="flex px-3 pt-2 pb-2" style={{color:'	#686868'}}> <MdOutlineColorLens/>&nbsp; &nbsp;Ui elements</div>
  <div class="flex px-3 pt-2 pb-2" style={{color:'	#686868'}}> <GoThreeBars />&nbsp;&nbsp;Advanced Ui</div>
  <div class="flex px-3 pt-2 pb-2" style={{color:'	#686868'}}> <BiNotepad />&nbsp;&nbsp;Form Elements</div>
  <div class="flex px-3 pt-2 pb-2" style={{color:'	#686868'}}> <AiFillEdit />&nbsp;&nbsp;Editors</div>
  <div class="flex px-3 pt-2 pb-2" style={{color:'	#686868'}}> <BsBarChart cl/>&nbsp;&nbsp;Charts</div>
  <div class="flex px-3 pt-2 pb-2" style={{color:'	#686868'}}> <RiTable2 />&nbsp;&nbsp;Tables</div>
  <div class="flex px-3 pt-2 pb-2" style={{color:'	#686868'}}> <MdOutlineNotifications/>&nbsp;&nbsp;Notifications</div>
  <div class="flex px-3 pt-2 pb-2" style={{color:'	#686868'}}> <BsEmojiSmile/>&nbsp;&nbsp;icons</div>
  <div class="flex px-3 pt-2 pb-2" style={{color:'	#686868'}}> <SiGooglemaps/>&nbsp;&nbsp;Maps</div>
  <div class="flex px-3 pt-2 pb-2" style={{color:'	#686868'}}> <GiPapers />&nbsp;&nbsp;User pages</div>
  <div class="flex px-3 pt-2 pb-2" style={{color:'	#686868'}}> <BiMessageAltError/>&nbsp;&nbsp;Error pages</div>
  <div class="flex px-3 pt-2 pb-2" style={{color:'	#686868'}}> <RiFilePaper2Line />&nbsp;&nbsp;General pages</div>
  <div class="flex px-3 pt-2 pb-2" style={{color:'	#686868'}}> <AiOutlineShoppingCart />&nbsp;&nbsp;Ecommerce</div>
  <div class="flex px-3 pt-2 pb-2" style={{color:'	#686868'}}> <GrDocumentStore/>&nbsp;&nbsp;Documentation</div>
  
  

 

 

</table>
</div>
     
     <div class="col-span-4">

     

      <nav class="bg-#e5e6eb">
          <div class="flex">
              <div class=" mr-auto mt-6  ">
                {/* <MenuOutlined/> &nbsp;&nbsp; */}
                <AppsIcon/> &nbsp;&nbsp;
                <SearchOutlined/> <h4>Serach now</h4>
              </div>
              <div class="flex justify-self-end pb-2">
                  {/* <div class="mr-8 mt-6"><SearchOutlined/></div> */}
                  <div class="mr-8 mt-6"><MailOutlineIcon/></div>
                  <div class="mr-8 mt-6"><NotificationImportantOutlined/></div>
               
                  {/* <div class="mr-8 mt-6"><ChatSharp/></div>
                  <div class="mr-8 mt-6"><ShoppingCart/></div> */}
                  <div class="h-10 w-10 mr-6 mt-3"><img src="/img/ab.png" class= " rounded-full "/></div>
              </div>
          </div>
      </nav>

        
       <div class="grid grid-cols-3 pb-6">
            
            {/* {<div class="col-span-2 border-2 p-6 mt-8 ml-8 bg-white text-gray-600 h-auto"> */}
            <div class="col-span-3 p-6 border-2 mt-4 ml-4 bg-white text-gray-600 mr-6">
                <h3 class="pb-5">Hi,Welcomeback!. &nbsp; &nbsp; &nbsp;&nbsp;&nbsp; &nbsp; &nbsp;&nbsp;&nbsp;  &nbsp; &nbsp; &nbsp;&nbsp;&nbsp; &nbsp; &nbsp;&nbsp;&nbsp;Balance | &nbsp; &nbsp; &nbsp;&nbsp;&nbsp;Today's Profit | &enbsp; &nbsp; &nbsp;&nbsp;&nbsp;</h3>
                <h3 class="pb-5">JustDo Dashboard, </h3>
                <h3 class="pb-3"></h3>
                <div class="w-40 h-2 bg-sky-600 rounded-full pb-3"></div>
                <h3 class="pb-3"></h3>
                <div class="w-40 h-2 bg-sky-600 rounded-full pb-3"></div>
                <h3 class="pb-3"></h3>
                <div class="w-40 h-2 bg-sky-600 rounded-full pb-3"></div>
                <h3 class="pb-3"></h3>
                <div class="w-40 h-2 bg-sky-600 rounded-full pb-3"></div>
                <h4 class="w-auto"></h4>
            </div> }

            {/* <div class="col-span-2 p-6 border-2 mt-4 ml-4 bg-white mr-6">
                { <table class="table-fixed">
                    <thead class="border-b-2 bg-slate-400 ">
                        <tr>
                        <th class="px-2 p-3 flex">First Name</th>
                        <th class="px-5 p-3"> Last Name</th>
                        <th class="px-3 p-3">City</th>
                        <th class="px-4 p-3">Street</th>
                        </tr> 
                    </thead> 
                    

                    { <tbody class="text-gray-600">
                        <tr class="border-b-2">
                            <td class="px-8 p-3">Emelia</td>
                            <td class="px-8 p-3">Gislason</td>
                            <td class="px-16 p-3">Lake Zeida</td>
                            <td class="px-4 p-3">Kulas Shoals</td>
                        </tr>
                        <tr class="border-b-2">
                            <td class="px-8 p-3">clyod</td>
                            <td class="px-8 p-3">Armstrong</td>
                            <td class="px-16 p-3">East piece</td>
                            <td class="px-4 p-3">Lyla Heights</td>
                        </tr>
                        <tr class="border-b-2">
                            <td class="px-8 p-3">Rahul</td>
                            <td class="px-8 p-3">Funk</td>
                            <td class="px-16 p-3">Sibylside</td>
                            <td class="px-4 p-3">jolie Shoals</td>
                        </tr>
                        <tr class="border-b-2">
                            <td class="px-8 p-3">Hibert</td>
                            <td class="px-8 p-3">Langosh</td>
                            <td class="px-16 p-3">Anaisshire</td>
                            <td class="px-4 p-3">Sim Station</td>
                        </tr>
                        <tr class="border-b-2">
                            <td class="px-8 p-3">Cloyd</td>
                            <td class="px-8 p-3">Wilderman</td>
                            <td class="px-16 p-3">North Brad</td>
                            <td class="px-4 p-3">Ruecker Turnpike</td>
                        </tr>

                    </tbody>}

                </table>}
            </div>
        </div> 

         

        <div>
      <nav>
          <div class="grid grid-cols-4 text-white rounded mt-6">
            
            <div class="flex bg-purple-500 w-60 rounded ">
             <img src="/img/msg.png" class="h-20 w-20 p-5 bg-purple-600 rounded-l-lg"/>
             <div class="pt-3 px-3">
                <h4 class="font-bold text-xl">210</h4>
                <h4 class=" text-lg">Unread Email</h4>
             </div>
             </div>

             <div class="flex bg-sky-400 w-60 rounded">
             <img src="/img/cam.png" class="h-20 w-20 p-5 bg-sky-500 rounded-l-lg"/>
             <div class="pt-3 px-3">
                <h4 class="font-bold text-xl">210</h4>
                <h4 class="text-lg">Image Upload</h4>
             </div>
             </div>

             <div class="flex bg-lime-400 w-60 rounded">
             <img src="/img/chat.png" class="h-20 w-20 p-5 bg-lime-500 rounded-l-lg"/>
             <div class="pt-3 px-3">
                <h4 class="font-bold text-xl">210</h4>
                <h4 class=" text-lg">Total Message</h4>
             </div>
             </div>

             <div class="flex bg-pink-400 w-60 rounded">
             <img src="/img/cart.png" class="h-20 w-20 p-5 bg-pink-500 rounded-l-lg"/>
             <div class="pt-3 px-3">
                <h4 class="font-bold text-xl">210</h4>
                <h4 class=" text-lg">Orders Post</h4>
             </div>
             </div>
          </div>
      </nav>
      
      <div class="grid grid-cols-4 pb-6">
  
        <div class="p-4 bg-white mr-3 mt-4 w-60">
          <h4 class="font-bold text-sm pb-4">INCOME</h4>
          <h4 class="text-3xl text-pink-500 pb-5">$15000</h4>
          <h4 class=" w-52 pb-4">Lorem ipsum dolor sit amet consectetur adipisicing elit sed do eiusmod tempor</h4>
        </div>

        <div class="p-4 bg-white mr-3 mt-4 w-60">
          <h4 class="font-bold text-sm pb-4">INCOME</h4>
          <h4 class="text-3xl text-pink-500 pb-5">$15000</h4>
          <h4 class=" w-52 pb-4">Lorem ipsum dolor sit amet consectetur adipisicing elit sed do eiusmod tempor</h4>
        </div>
        
        <div class="p-4 bg-white mr-3 mt-4 w-60">
          <h4 class="font-bold text-sm pb-4">INCOME</h4>
          <h4 class="text-3xl text-pink-500 pb-5">$15000</h4>
          <h4 class=" w-52 pb-4">Lorem ipsum dolor sit amet consectetur adipisicing elit sed do eiusmod tempor</h4>
        </div>

        <div class="p-4 bg-white mr-3 mt-4 w-60">
          <h4 class="font-bold text-sm pb-4">INCOME</h4>
          <h4 class="text-3xl text-pink-500 pb-5">$15000</h4>
          <h4 class=" w-52 pb-4">Lorem ipsum dolor sit amet consectetur adipisicing elit sed do eiusmod tempor</h4>
        </div>
      </div> */}

    </div>



      </div>
    </div>
  ) 
}
export default Project