import React from 'react';
import './Style.css';

const Part1 = () => {
  return (
    <div class="">
        <div class="grid grid-cols-4 pb-6">
            <div></div>
            <div class="col-span-1 border-2 p-6 mt-4 bg-white h-60 text-gray-600">
                <h3>Income</h3>
                <div class="w-40 h-2 bg-sky-600 rounded-full"></div>
                <h3>Marketing</h3>
                <div class="w-40 h-2 bg-sky-600 rounded-full"></div>
                <h3>Consulting</h3>
                <div class="w-40 h-2 bg-sky-600 rounded-full"></div>
                <h3>Development</h3>
                <div class="w-40 h-2 bg-sky-600 rounded-full"></div>
                <h4 class="w-auto">Lorem ipsum dolor sit met consectelur adipisicing elit sed do eiusmod tempor</h4>
            </div>

            <div class="col-span-2 p-6 border-2 mt-4 ml-4 bg-white mr-6">
                <table class="table-fixed">
                    <thead class="border-b-2 bg-gray-200 ">
                        <tr>
                        <th class="px-2 p-3 flex">First Name</th>
                        <th class="px-5 p-3"> Last Name</th>
                        <th class="px-3 p-3">City</th>
                        <th class="px-4 p-3">Street</th>
                        </tr> 
                    </thead>
                    

                    <tbody class="text-gray-600">
                        <tr class="border-b-2">
                            <td class="px-8 p-3">Emelia</td>
                            <td class="px-8 p-3">Gislason</td>
                            <td class="px-16 p-3">Lake Zeida</td>
                            <td class="px-4 p-3">Kulas Shoals</td>
                        </tr>
                        <tr class="border-b-2">
                            <td class="px-8 p-3">clyod</td>
                            <td class="px-8 p-3">Armstrong</td>
                            <td class="px-16 p-3">East piece</td>
                            <td class="px-4 p-3">Lyla Heights</td>
                        </tr>
                        <tr class="border-b-2">
                            <td class="px-8 p-3">Rahul</td>
                            <td class="px-8 p-3">Funk</td>
                            <td class="px-16 p-3">Sibylside</td>
                            <td class="px-4 p-3">jolie Shoals</td>
                        </tr>
                        <tr class="border-b-2">
                            <td class="px-8 p-3">Hibert</td>
                            <td class="px-8 p-3">Langosh</td>
                            <td class="px-16 p-3">Anaisshire</td>
                            <td class="px-4 p-3">Sim Station</td>
                        </tr>
                        <tr class="border-b-2">
                            <td class="px-8 p-3">Cloyd</td>
                            <td class="px-8 p-3">Wilderman</td>
                            <td class="px-16 p-3">North Brad</td>
                            <td class="px-4 p-3">Ruecker Turnpike</td>
                        </tr>

                    </tbody>

                </table>
            </div>
        </div>
    </div>
  )
}

export default Part1